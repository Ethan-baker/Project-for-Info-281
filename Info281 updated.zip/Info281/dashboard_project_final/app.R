library(devtools)
library(shiny)
library(shinydashboard)
library(tidyr)
library(tidyverse)
library(leaflet)
library(ggplot2)
library(plyr)
library(dplyr)
library(viridis)
library(usethis)
library(devtools)
library(dashboardthemes)
# formating and data ------------------------------------------------------

#Ethnicity data and formating 
ethnicity_data <- read.csv("../data/ethnicity.csv")
ethnicity_data_frame <- read.csv("../data/ethnicity.csv")
ethnicity_data$X <- NULL
ethnicity_data_frame <- data.frame(ethnicity_data)

colnames(ethnicity_data_frame) <-
    c("year_level","qualification","ethnicity","academic_year",
      
      "cumulative_year_attaintment_rate","current_year_attainment_rate",
      
      "cumulative_year_attainment","current_year_attainment",
      "total_student_count")


#Gender data and formating 
gender_data_frame <- read.csv("../data/gender.csv")
gender_data_frame$Typical.Level.Flag <- NULL
gender_data_frame$Cohort.Warning <- NULL


colnames(gender_data_frame) <-
    c("year_level_g","qualification_g","gender","academic_year_g",
      
      "cumulative_year_attaintment_rate_g","current_year_attainment_rate_g",
      
      "cumulative_year_attainment_g","current_year_attainment_g",
      "total_student_count_g")


#Map data and formating
alldata <- read.csv("../data/alldata.csv")

colnames(alldata) <- c("id","name","address","city","area_type","school_type",
                       "authority","coed_status","region","latitude","longitude",
                       "decile","total","european","maori","pacific","asian","MELAA",
                       "other","international","col_id","col_name")


#Decile break up by students

decile <- read.csv("../data/alldata.csv")


colnames(decile) <- c("id","name","address","city","area_type","school_type",
                      
                      "authority","coed_status","region","latitude","longitude",
                      
                      "decile","total","european","maori","pacific","asian","MELAA",
                      
                      "other","international","col_id","col_name")

decile_ethnicities <- gather(decile[c("id",
                                      
                                      "decile", "european","maori","pacific","asian","MELAA",
                                      
                                      "other","international")], key = "ethnicity", value ="count", -id, -decile)



collected_df_mean <- Rmisc::summarySE(decile_ethnicities, measurevar = "count",
                                      
                                      groupvars = c("ethnicity", "decile")) %>%
  filter(., decile %in% 1:10)





# Dashboard ---------------------------------------------------------------






ui <- dashboardPage(
    dashboardHeader(title = "NZ Education data"),
    dashboardSidebar(
        #Names and code for the side bar menu
        sidebarMenu(
            menuItem("Dashboard", tabName = "dashboard", icon = icon("dashboard")),
            menuItem("New Zealand Map", tabName = "map", icon = icon("map")),
            menuItem("Raw data sources", tabName = "sources", icon = icon("book")
            )
        )
    ),
    #Linking the tabs in the side bar to different parts of the UI so that it is functional 
    dashboardBody(
      
      shinyDashboardThemes(
      theme = "poor_mans_flatly"
      ),
      
        tabItems(
            
            tabItem(tabName = "dashboard",
                    h2("Breakdown of New Zealand Education Data"),
                    fluidRow(
                        #Layout and look of the ethnicity histogram
                        box(title = "Ethnicty Histogram", width = 8, plotOutput("ethnicity_data"), 
                            solidHeader = T, br(" "),
                            p("The Ethnicity
        Histogram shows the percentage of students that attained the selected level of qualification based on their ethnicity. 
        The goal of this graph is to show an easy to understand visualisation of the differences in education qualifications based
        on students' ethnicity in New Zealand. The 
        the purpose is to present the data so that people can make their assumptions around inequalities in 
        the education system.") ),
                        
                        #Layout and look of the inputs for the ethnicity histogram
                        box(
                            title = "Ethnicity controls", width = 4, solidHeader = T, 
                            selectInput("catagories_ethnicity","Select Students Qualifcation",
                                        choices = (ethnicity_data_frame$qualification
                                                   
                                                   
                                        ), c("1" = "NCEA level 1",
                                             "2" = "NCEA level 2",
                                             "3" = "NCEA level 3",
                                             "4" = "University Entrance")) )),
                        
                    
                    fluidRow(
                        box( title = "Gender Histogram", width = 8, plotOutput("gender_data"),
                             solidHeader = T, br(" "),
                             p("Similar to the Ethnicity Histogram, the Gender Histogram shows the percentage of students that 
                   attained the selected level of qualification based on their gender. The goal was to show a side by side 
                   comparison of the selected qualification level based on gender. The biggest inequality that I found with 
                   the gender data is the lack of self-identified genders available. This could lead to people that do not identify as 
                    male or female being neglected and underrepresented in the education system.")),
                        
                        box(title = "Gender controls", width = 4, solidHeader = T, multiple = TRUE,
                            selectInput("catagories","Select Students Qualifcation",
                                        choices = (gender_data_frame$qualification_g
                                                   
                                                   
                                        ), c("1" = "NCEA level 1",
                                             "2" = "NCEA level 2",
                                             "3" = "NCEA level 3",
                                             "4" = "University Entrance"))))
            ),
                  
        
            tabItem(tabName = "map",
                    h2("New Zealand Map with all schools"),
                    fluidRow( tabName = "map", 
                              box(leafletOutput("fm"), width = 12, br(""),p("Red markers are deciles one to four."),
                             p("Orange markers are deciles five to seven."), p("Green markers are deciles eight to ten."),
                             p("Gry markers are schools that do not have an official decile rating."),br(""),
                              p("The map is here so that you can see all the recorded schools across New Zealand.
                            By zooming in and clicking on individual schools you can see more information about that school. It shows the 
                            name, decile number, total student count and ethnicity of the students attending the school. The goal of this visualisation 
                            is so that you can get an understanding of where the low and high decile schools are located and see the difference
                            in ethnic groups that are attending different decile ratings. ")),
                   
                   box(title = "Number of Students by School Decile", plotOutput("ethnicity_decile"), width = 8, br(""), p("This graph is depicting the 
                   distribution of students by there ethnicity based on the decile of the school that they go to. The symbol on top of each bar indicates
                   the confidence intervals for each bar. This graph is not interactive, it is just there to provide a quick summary of the statistics based on what 
                   ethnicities are more likely to attend different schools and what the school's decile rating may be.                                                   
                    
                                                                                                                      ")
                        
                        
                      ),
                              
                              
                              )
                              
                    
                
            ),
            
            tabItem(tabName = "sources",
                h2("Raw data sources used to generate visulisations"),
                    
                    
                    box(title = "Data used for Ethnicity and Gender histogram", p("The source was the same publisher 
                    for the Ethnicity and Gender data. When following the link there are a few different data sets 
                    available for different things. The data sets used for this project are under the 
                    Standard Attainment Statistics files called National by Gender and National by Ethnicity. 
                    Link:https://www.nzqa.govt.nz/studying-in-new-zealand/secondary-school-and-ncea/find-information-about-a-school/secondary-school-statistics/data-files-for-2/")),
                    
                    box(title = "Data used for map",p("The link to the website for the data used in the map can be
                    found at the bottom of this paragraph.   
                    The data can be filtered on the site before download if you know what you are looking for. 
                    Link:https://www.educationcounts.govt.nz/data-services/directories/list-of-nz-schools# ")),
                
                    box(title = "Github repository", p("Here is a link to my Github repository if you want to see the code 
                                                       https://github.com/Ethan-baker/Project-for-Info-281"))
                
                
            )),
        
        
        
        
        
    ))



# Server ------------------------------------------------------------------
server <- function(input, output) {
  

# ethnicity code ----------------------------------------------------------

    
    output$ethnicity_data <- renderPlot({
        print(input$catagories)
        
        ethnicity_data_frame$current_year_atttainment_rate <-
            as.numeric(gsub("%","",ethnicity_data_frame$current_year_attainment_rate))
        
        ethnicity_data_frame$ethnicity <- 
            (gsub(x= ethnicity_data_frame$ethnicity, pattern = "M\\?ori", replacement = "Maori"))
        
        if(nchar(input$catagories_ethnicity)==0){
            plotData <- ethnicity_data_frame
        } else {
            plotData <- filter(ethnicity_data_frame, qualification ==
                                   input$catagories_ethnicity)
        }
        
        ggplot(plotData) +
            aes(x = factor(academic_year), y =
                    current_year_atttainment_rate, fill=ethnicity)  +
            geom_col(position = "dodge") +
            theme(axis.text.x = element_text(angle = 90, vjust = .40)) +
            labs(x = "Year", y = "Percentage of attainment") + scale_fill_viridis( discrete = T, option = "D") 

    })
    

# gender code -------------------------------------------------------------

    
    output$gender_data <- renderPlot({
        print(input$catagories)
        
        gender_data_frame$current_year_atttainment_rate_g <-
            as.numeric(gsub("%","",gender_data_frame$current_year_attainment_rate_g))
        
        if(nchar(input$catagories)==0){
            plotData <- gender_data_frame
        } else {
            plotData <- filter(gender_data_frame, qualification_g ==
                                   input$catagories)
        }
        
        ggplot(plotData) +
            aes(x = factor(academic_year_g), y =
                    current_year_atttainment_rate_g, fill=gender)  +
            geom_col(position = "dodge") +
            theme(axis.text.x = element_text(angle = 90, vjust = .40)) +
            labs(x = "Year", y = "Percentage of attainment")+ scale_fill_viridis( discrete = T, option = "C")
    })
    output$value <- renderPrint({ input$decile })
    
    

# Map code ----------------------------------------------------------------

    
    
    
    #assign color based on the decile rating 
    map_color <- function(alldata){
        sapply(alldata$decile, function(decile) {
            if(is.na(decile)){
                NA
            } else if(decile <= 4) {
                "red"
            } else if(decile %in% 5:7 ) {
                "orange"
            } else if(decile == 99) {
                "grey"
            } else {
                "green"
            }
        }) 
    }
    
    
    
    
    #assigning the icons color that was pre-defined above
    icons <- awesomeIcons(
        icon = 'ios-close',
        iconColor = 'black',
        library = 'ion',
        markerColor = map_color(alldata)
    )
    
    
    
    #the info that will go inside the schools data on the ethnicities in the school
    content <- data.frame(alldata$name,alldata$decile, alldata$authority,alldata$total,alldata$european,
            alldata$maori,alldata$pacific,alldata$asian,alldata$MELAA,alldata$other,
            alldata$international)
    
    contentToPrint <- apply(content, 1, function(x){
        paste0(x[1],"<p> Decile rating:",x[2],"<br /> Authority: ",
                
               x[3],"<p>Total students:",x[4],"<br /> European students:",x[5],"<br /> Maori students:",x[6],
               "<br /> Pasifika students:",x[7],"<br /> Asian students:",x[8],"<br /> MELAA students:",x[9],
               "<br /> Other students:",x[10],"<br /> International students:",x[11])
    })
    
    
    output$fm <- renderLeaflet({
        
        leaflet(alldata) %>%
            addTiles() %>%
            setView(lat = -41.32109, lng = 174.7735, zoom = 4)%>%
            addAwesomeMarkers(lat = alldata$latitude, lng = alldata$longitude, popup = contentToPrint,
                              icon = icons, clusterOptions = markerClusterOptions(zoomToBoundsOnClick = T))
    })
    
    #Code for the Ethnicity by school decile 
    
   output$ethnicity_decile <- renderPlot({
     collected_df_mean %>%
      
      ggplot() +
      
      aes(x = factor(decile), y = count, fill = ethnicity, ymin = count - ci, ymax = count + ci) +
      
      geom_bar(stat = "identity", position = "dodge") +
      
      geom_errorbar(position = "dodge") +
      
      
      theme(axis.text.x = element_text(angle = 90, vjust = .40)) +  
      labs(x = "Decile", y = "Number of Students") + scale_fill_viridis( discrete = T, option = "C")
    
    
   })
    
    
    
}

shinyApp(ui, server)