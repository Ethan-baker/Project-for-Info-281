library(tidyr)
library(tidyverse)
library(leaflet)
library(ggplot2)
library(plyr)
library(dplyr)
library(htmltools)
library(patchwork)


# map code ----------------------------------------------------------------




alldata <- read.csv("data/alldata.csv")


colnames(alldata) <- c("id","name","address","city","area_type","school_type",
                      "authority","coed_status","region","latitude","longitude",
                      "decile","total","european","maori","pacific","asian","MELAA",
                      "other","international","col_id","col_name")
colnames(content) <- c("name","total","european","maori","pacific","asian","MELAA",
                       "other","international")



#use this when I clear the cache to reload fm
fm <- leaflet()
  addTiles() %>%
    
fm



# working map
fm <- leaflet(alldata) %>%
  addTiles() %>%
  setView(lat = -41.32109, lng = 174.7735, zoom = 4)%>%
  addAwesomeMarkers(lat = alldata$latitude, lng = alldata$longitude, popup = contentToPrint,
                    icon = icons, clusterOptions = markerClusterOptions(zoomToBoundsOnClick = T))
fm



#assign color based on the decile rating 
map_color <- function(alldata){
  sapply(alldata$decile, function(decile) {
    if(is.na(decile)){
      NA
    } else if(decile <= 4) {
      "red"
    } else if(decile %in% 5:7 ) {
      "blue"
    } else if(decile == 99) {
      "green"
    } else {
      "purple"
    }
  }) 
}


#assigning the icons color that was pre-defined above
icons <- awesomeIcons(
  icon = 'ios-close',
  iconColor = 'black',
  library = 'ion',
  markerColor = map_color(alldata)
)



#the info that will go inside the schools data on the ethnicities in the school
content <- data.frame(alldata$name,alldata$decile,alldata$total,alldata$european,alldata$maori,alldata$pacific,alldata$asian,alldata$MELAA,alldata$other,alldata$international)

contentToPrint <- apply(content, 1, function(x){
 paste0(x[1],"<p> Decile rating:",x[2],"<p>Total students:", x[3], "<br /> European students:",x[4],"<br /> Maori students:",x[5],
        "<br /> Pasifika students:",x[6],"<br /> Asian students:",x[7],"<br /> MELAA students:",x[8],
        "<br /> Other students:",x[9],"<br /> International students:",x[10])
})










# ethncitiy visulisation code ---------------------------------------------



ethnicity_data <- read.csv("data/ethnicity.csv")
ethnicity_data$X <- NULL
colnames(ethnicity_data) <- c("year_level","qualification","ethnicity","academic_year",
                              "cumulative_year_attaintment_rate","current_year_atttainment_rate",
                              "cumulative_year_attainment","current_year_attainment","total_students")


# formating the data so it is easier to use 
ethnicity_data$current_year_atttainment_rate <- as.numeric(gsub("%","",ethnicity_data$current_year_atttainment_rate))
ethnicity_data$ethnicity <- gsub(x= ethnicity_data$ethnicity,pattern =  "M\\?ori",replacement = "maori")
ethnicity_data$qualification <- gsub(x= ethnicity_data$qualification,pattern =  "University Entrance",replacement = "ue")


 
# To search for multiple ethnicities have to put it in a vector and then use the % sign so that it does not just search for the first function 
ethnicity_data <- dplyr::filter(ethnicity_data, ethnicity %in% c("maori", "European"),
                                qualification == "ue", year_level == "13")



# Histogram with the two different ethnicities next to each other for easy comparison
ggplot(ethnicity_data) +
  aes(x = factor(academic_year), y = current_year_atttainment_rate, fill=ethnicity)  +
  geom_col(position = "dodge") +
  theme(axis.text.x = element_text(angle = 90, vjust = .40)) +
  labs(x = NULL)
    










# Gender visulisation code ------------------------------------------------

gender_data <- read.csv("data/gender.csv")
gender_data$Typical.Level.Flag <- NULL
gender_data$Cohort.Warning <- NULL
view(gender_data)


colnames(gender_data) <- c("year_level_g","qualification_g","gender","academic_year_g",
                          "cumulative_year_attaintment_rate_g","current_year_attainment_rate_g",
                          "cumulative_year_attainment_g","current_year_attainment_g",
                          "total_student_count_g")


gender_data$current_year_atttainment_rate_g <- as.numeric(gsub("%","",gender_data$current_year_attainment_rate_g))
gender_data$qualification_g <- gsub(x= gender_data$qualification_g,pattern =  "University Entrance",replacement = "ue")

gender_data <- dplyr::filter(gender_data, qualification_g == "ue", year_level_g == "13")



# Histogram showing the different genders and corrisponding data 
ggplot(gender_data) +
  aes(x = factor(academic_year_g), y = current_year_atttainment_rate_g, fill=gender)  +
  geom_col(position = "dodge") +
  theme(axis.text.x = element_text(angle = 90, vjust = .40)) +
  labs(x = NULL)




